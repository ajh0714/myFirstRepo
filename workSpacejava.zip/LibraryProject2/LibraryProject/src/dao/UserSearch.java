package dao;

import data.UserDB;
import vo.UserVO;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserSearch {
    Scanner scan = new Scanner(System.in);

    public UserSearch(){}
    public List<UserVO> userSearchStart(){
        return null;
    }
}
