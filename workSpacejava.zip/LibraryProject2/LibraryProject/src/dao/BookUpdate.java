package dao;

import data.BookDB;
import data.UserDB;

import java.util.Scanner;

public class BookUpdate {
    Scanner scan = new Scanner(System.in);
    public BookUpdate(){}
    public void bookUpdateStart(){

    }
}
