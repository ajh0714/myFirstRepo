package dao;

import data.BookDB;

import java.util.Scanner;

public class BookDelete {
    Scanner scan = new Scanner(System.in);

    public BookDelete(){}
    public void bookDeleteStart(){
        //Delete 로직
    }
}
