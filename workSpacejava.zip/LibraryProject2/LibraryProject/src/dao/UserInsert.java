package dao;

import data.UserDB;
import vo.UserVO;

import java.util.Scanner;

public class UserInsert extends UserVO {
    Scanner scan = new Scanner(System.in);
    public UserInsert(){};

    public void userInsertStart() {

    }

}
