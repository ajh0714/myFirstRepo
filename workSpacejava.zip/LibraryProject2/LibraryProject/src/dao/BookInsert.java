package dao;

import data.BookDB;
import data.UserDB;
import vo.BookVO;

import java.util.Scanner;

public class BookInsert extends BookVO {
    Scanner scan = new Scanner(System.in);
    public BookInsert(){};

    public void bookInsertStart() {
    }
}
