package dao;

import data.UserDB;

import java.util.Scanner;

public class UserUpdate {
    Scanner scan = new Scanner(System.in);

    public UserUpdate(){}
    public void userUpdateStart() {

    }
}
