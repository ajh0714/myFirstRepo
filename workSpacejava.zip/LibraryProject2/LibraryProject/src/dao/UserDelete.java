package dao;

import data.UserDB;

import java.util.Scanner;

public class UserDelete {
    Scanner scan = new Scanner(System.in);

    public UserDelete(){}
    public void userDeleteStart(){

    }
}
