package dao;

import vo.UserVO;

import java.util.List;

public class UserSelect {
    public UserSelect(){}

    public void userList(List<UserVO> uv) {

    }
}
