package dao;

import data.BookDB;
import data.UserDB;
import vo.BookVO;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BookSearch {
    Scanner scan = new Scanner(System.in);
    public BookSearch(){}

    public List<BookVO> bookSearchStart(){
        return null;
    }
}
