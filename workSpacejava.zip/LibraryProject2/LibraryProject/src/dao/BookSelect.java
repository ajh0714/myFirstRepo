package dao;

import vo.BookVO;

import java.util.List;

public class BookSelect {
    public BookSelect(){}

    public void bookList(List<BookVO> bv) {

    }
}
