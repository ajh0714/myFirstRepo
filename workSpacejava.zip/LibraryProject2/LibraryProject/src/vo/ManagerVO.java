package vo;

public class ManagerVO {
    //관리자 정보 담는곳
}
