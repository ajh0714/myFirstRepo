package vo;

import data.UserDB;

public class BookVO extends UserVO{
    //UserVO 상속 받은거 확인

    //책 정보 변수 놓기

    //getter

    //setter

    //toString Override ㄱㄱ
}
