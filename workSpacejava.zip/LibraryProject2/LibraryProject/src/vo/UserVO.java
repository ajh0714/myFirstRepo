package vo;

public class UserVO {
    //이용자 정보 변수 놓기

    //getter

    //setter

    //toString Override ㄱㄱ
}
