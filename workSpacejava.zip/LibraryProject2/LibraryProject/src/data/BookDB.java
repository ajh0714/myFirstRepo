package data;

import vo.BookVO;

import java.util.ArrayList;
import java.util.List;

public class BookDB {
    public static List<BookVO> bookList = new ArrayList<>();
    public BookDB(){}
    public static void setBook(){
        //북 리스트에 add 해주기
    }
}
