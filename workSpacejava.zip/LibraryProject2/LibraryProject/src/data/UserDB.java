package data;

import vo.UserVO;

import java.util.ArrayList;
import java.util.List;

public class UserDB {
    public static List<UserVO> userList = new ArrayList<>();
    public UserDB(){}
    public static void setUser(){
        //유저 리스트에 add 하기
   }
}
