package data;

import vo.ManagerVO;

public class ManagerDB {
    public ManagerDB() {}
   // public static ManagerVO manager = new ManagerVO("admin","1234");
    //ManagerVO 짜고 매니저 위에 정보 담기
}
