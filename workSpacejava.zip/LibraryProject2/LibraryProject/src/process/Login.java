package process;

import data.ManagerDB;

import java.util.Scanner;

public class Login {
    Scanner scan = new Scanner(System.in);

    //로그인 id pw 담을 변수 놓기

    public Login(){}
    public void processLogin(){
       //로그인 과정 담기
    }
}
