package test_package;
// Test는 클래스명이다
public class test {
    public static void test(String args[]) {
        System.out.println("처음실행하는 자바클래스");
        //main()는 메소드이다.
        int a = 500; // 제일큰값
        /*
            여러줄 주석은 작성하기
            자바는 실행하면 main()메소드가 자동 호출된다.
         */
    }
}
    // 프로그램 마지막이다.
