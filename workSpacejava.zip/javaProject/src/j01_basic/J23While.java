package j01_basic;

public class J23While {
    public static void main(String[] args) {
        int i=0; // 고치면 안됨. 1~5
        while(++i<=5){
            System.out.println(i);

        }
    }
}
