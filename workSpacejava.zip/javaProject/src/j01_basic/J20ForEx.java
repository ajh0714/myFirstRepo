package j01_basic;

public class J20ForEx {
    public static void main(String[] args) {
        for(int i=1; i<=100; i++){
           if(i%3!=0 && i%5!=0)
            System.out.println(i);
        }
    }
}
