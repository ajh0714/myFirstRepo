package j01_basic;

public class J25DoWhile {
    public static void main(String[] args) {
        int i=0;
        do{
            i++;
            System.out.println(i);
        }while(i<5);
    }
}
