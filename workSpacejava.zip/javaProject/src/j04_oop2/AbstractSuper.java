package j04_oop2;

public abstract class AbstractSuper {
    public AbstractSuper(){}

    public abstract int divide(int a, int b);
}
