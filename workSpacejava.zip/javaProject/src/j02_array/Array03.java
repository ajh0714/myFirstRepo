package j02_array;

public class Array03 {
    public static void main(String[] args) {
        // main()메소드의 String배열 매개변수(argusments)는 클래스 실행시 외부에서
        // 클래스내로 문자데이터를 가져 올 수 있다.
        System.out.println("main()메소드 매개변수 테스트");

    }
}
