package j08_collection;

import java.util.Properties;

public class PropertiesTest {
    public PropertiesTest(){}
    public void start(){
        // key와 value를 문자열로 표기하여야 한다.
        Properties prop = new Properties();

    }

    public static void main(String[] args) {
        new PropertiesTest().start();
    }
}
