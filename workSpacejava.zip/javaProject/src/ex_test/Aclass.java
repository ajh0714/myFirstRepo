package ex_test;

class Aclass {
    public int a;
    protected Aclass(int a){this.a=a;}
}