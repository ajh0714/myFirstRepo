package ex_test;

public class Test {
    protected static int add(int a, int b){
        return a+b;
    }
}
