package ex_test;

public class A {

    public double test(int x){
        return 1.0;
    }

    public static void main(String[] args) {
        A t=new A();
        System.out.println(t.test(25));
    }
}
