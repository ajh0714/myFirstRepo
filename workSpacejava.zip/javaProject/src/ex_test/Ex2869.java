package ex_test;

import java.util.Scanner;

public class Ex2869 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int A = scan.nextInt();
        int B = scan.nextInt();
        int V = scan.nextInt();
        for(int i=0; ; i++ ){
        }
    }
}
