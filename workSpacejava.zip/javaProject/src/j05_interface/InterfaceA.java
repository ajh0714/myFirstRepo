package j05_interface;

public interface InterfaceA {
    public int multiple(int a, int b);
}
